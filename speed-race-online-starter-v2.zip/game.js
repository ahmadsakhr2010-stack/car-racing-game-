import * as THREE from "https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.module.js";
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import { getDatabase, ref, set, get, update, onValue, remove, serverTimestamp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-database.js";

// ضع بيانات مشروع Firebase هنا بعد اتباع تعليمات README_AR.txt
const firebaseConfig = {
  apiKey: "ضع_API_KEY_هنا",
  authDomain: "ضع_AUTH_DOMAIN_هنا",
  databaseURL: "ضع_DATABASE_URL_هنا",
  projectId: "ضع_PROJECT_ID_هنا",
  storageBucket: "ضع_STORAGE_BUCKET_هنا",
  messagingSenderId: "ضع_MESSAGING_SENDER_ID_هنا",
  appId: "ضع_APP_ID_هنا"
};

const $ = id => document.getElementById(id);
const screens = ["lobby","waiting","race","result"];
function show(id){ screens.forEach(s=>$(s).classList.toggle("hidden",s!==id)); }
let app, db, roomId=null, playerId=crypto.randomUUID(), playerName="", selectedCar="red", isHost=false, roomData=null, unsub=null;
let scene,camera,renderer,carMeshes=[], roadGroup, animationId, gas=false, progress=0, opponentProgress=0, raceStarted=false, finishShown=false, lastSend=0;
const carColors={red:0xe63838,blue:0x238eea,yellow:0xf2c52d,green:0x24bd76,purple:0x9b59d0,black:0x171c24};
const carNames={red:"رياضية حمراء",blue:"رياضية زرقاء",yellow:"سوبر صفراء",green:"رياضية خضراء"};

function setStatus(t){$("status").textContent=t}
function firebaseReady(){return firebaseConfig.apiKey!=="ضع_API_KEY_هنا" && firebaseConfig.databaseURL.includes("firebaseio.com") || firebaseConfig.databaseURL.includes("firebasedatabase.app")}
function connectFirebase(){
  if(!firebaseReady()) throw new Error("يجب أولاً وضع إعدادات Firebase في ملف game.js كما هو موضح في اقرأني.");
  if(!app){app=initializeApp(firebaseConfig);db=getDatabase(app);}
}
document.querySelectorAll(".carChoice").forEach(b=>b.addEventListener("click",()=>{
  selectedCar=b.dataset.car;document.querySelectorAll(".carChoice").forEach(x=>x.classList.toggle("selected",x===b));
}));
document.querySelectorAll(".colorDot").forEach(b=>b.addEventListener("click",()=>{document.querySelectorAll(".colorDot").forEach(x=>x.classList.toggle("active",x===b));}));
function randomCode(){return Math.random().toString(36).slice(2,8).toUpperCase()}
function getBuild(){return {color:document.querySelector(".colorDot.active")?.dataset.color||selectedCar,spoiler:$("spoiler").checked,neon:$("neon").checked,sportWheels:$("sportWheels").checked,engine:Number($("engineLevel").value||1)}}
function playerRecord(){return {name:playerName,car:selectedCar,build:getBuild(),progress:0,finished:false,joinedAt:Date.now()}}
async function createRoom(){
  playerName=$("playerName").value.trim()||"اللاعب الأول";
  try{connectFirebase();isHost=true;roomId=randomCode();
    const roomRef=ref(db,`rooms/${roomId}`);
    await set(roomRef,{host:playerId,status:"waiting",createdAt:serverTimestamp(),players:{[playerId]:playerRecord()}});
    enterRoom();
  }catch(e){setStatus(e.message||"تعذر إنشاء الغرفة.");}
}
async function joinRoom(){
  playerName=$("playerName").value.trim()||"اللاعب الثاني";roomId=$("roomCode").value.trim().toUpperCase();
  if(roomId.length!==6){setStatus("اكتب رمز الغرفة المكوّن من 6 أحرف.");return}
  try{connectFirebase();const rr=ref(db,`rooms/${roomId}`),snap=await get(rr);
    if(!snap.exists()){setStatus("الغرفة غير موجودة. تأكد من الرمز.");return}
    const data=snap.val();if(Object.keys(data.players||{}).length>=2 && !data.players[playerId]){setStatus("الغرفة ممتلئة، فيها لاعبان بالفعل.");return}
    if(data.status==="racing"){setStatus("السباق بدأ بالفعل.");return}
    await set(ref(db,`rooms/${roomId}/players/${playerId}`),playerRecord());isHost=false;enterRoom();
  }catch(e){setStatus(e.message||"تعذر دخول الغرفة.");}
}
function enterRoom(){
  show("waiting");$("shownCode").textContent=roomId;
  if(unsub)unsub();
  unsub=onValue(ref(db,`rooms/${roomId}`),snap=>{
    if(!snap.exists()){setStatus("انتهت الغرفة.");return}
    roomData=snap.val();renderPlayers();
    if(roomData.status==="racing" && !$("race").classList.contains("hidden")) return;
    if(roomData.status==="racing"){startRaceView();return}
  });
}
function renderPlayers(){
  const ps=Object.entries(roomData.players||{});
  $("players").innerHTML=ps.map(([id,p])=>`<div class="playerCard"><b>${escapeHtml(p.name)}</b><br>${carNames[p.car]||"سيارة"}<br><small>${id===roomData.host?"منشئ الغرفة":"متسابق"}</small></div>`).join("");
  $("waitingText").textContent=ps.length<2?"أرسل الرمز لصديقك وانتظر انضمامه.":"اللاعبان جاهزان! يمكن بدء السباق.";
  $("startRace").disabled=!(isHost&&ps.length===2);
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
$("createRoom").onclick=createRoom;$("joinRoom").onclick=joinRoom;
$("copyCode").onclick=async()=>{try{await navigator.clipboard.writeText(roomId);$("copyCode").textContent="تم النسخ ✓"}catch{$("copyCode").textContent=roomId}};
$("startRace").onclick=async()=>{if(!isHost)return;await update(ref(db,`rooms/${roomId}`),{status:"racing",startAt:Date.now()})};
$("leaveRoom").onclick=async()=>{if(unsub)unsub();if(db&&roomId){await remove(ref(db,`rooms/${roomId}/players/${playerId}`)).catch(()=>{});}roomId=null;show("lobby")};
$("raceAgain").onclick=()=>{show("waiting");progress=0;opponentProgress=0;finishShown=false};

function makeCar(color, build={}){
 const group=new THREE.Group(), paint=new THREE.MeshStandardMaterial({color,metalness:.72,roughness:.24}), glass=new THREE.MeshStandardMaterial({color:0x17364b,metalness:.3,roughness:.15});
 const body=new THREE.Mesh(new THREE.BoxGeometry(1.55,.42,3.1),paint);body.position.y=.55;group.add(body);
 const cabin=new THREE.Mesh(new THREE.BoxGeometry(1.12,.52,1.45),glass);cabin.position.set(0,.98,-.25);group.add(cabin);
 const hood=new THREE.Mesh(new THREE.BoxGeometry(1.45,.18,.8),paint);hood.position.set(0,.76,1.05);group.add(hood);
 const wheelMat=new THREE.MeshStandardMaterial({color:build.sportWheels?0x9aa7b2:0x111111,metalness:build.sportWheels?.7:.1,roughness:.6});
 for(const x of [-.82,.82])for(const z of [-.95,1.0]){const w=new THREE.Mesh(new THREE.CylinderGeometry(build.sportWheels?.35:.32,build.sportWheels?.35:.32,.18,build.sportWheels?20:16),wheelMat);w.rotation.z=Math.PI/2;w.position.set(x,.34,z);group.add(w)}
 if(build.spoiler){const wing=new THREE.Mesh(new THREE.BoxGeometry(1.65,.12,.38),paint);wing.position.set(0,1.02,-1.42);group.add(wing);for(const x of [-.52,.52]){const support=new THREE.Mesh(new THREE.BoxGeometry(.09,.32,.09),paint);support.position.set(x,.83,-1.42);group.add(support)}}
 if(build.neon){const glow=new THREE.Mesh(new THREE.BoxGeometry(1.9,.035,2.8),new THREE.MeshBasicMaterial({color:0x20dfff}));glow.position.set(0,.22,0);group.add(glow)}
 return group;
}
function initScene(){
 const root=$("gameCanvas");root.innerHTML="";
 scene=new THREE.Scene();scene.background=new THREE.Color(0x8cc7e8);scene.fog=new THREE.Fog(0x8cc7e8,35,130);
 camera=new THREE.PerspectiveCamera(55,root.clientWidth/root.clientHeight,.1,300);camera.position.set(0,8,14);camera.lookAt(0,0,-8);
 renderer=new THREE.WebGLRenderer({antialias:true});renderer.setPixelRatio(Math.min(devicePixelRatio,1.7));renderer.setSize(root.clientWidth,root.clientHeight);renderer.shadowMap.enabled=true;root.appendChild(renderer.domElement);
 scene.add(new THREE.HemisphereLight(0xffffff,0x526b4a,2));
 const sun=new THREE.DirectionalLight(0xffffff,2.3);sun.position.set(-8,18,10);sun.castShadow=true;scene.add(sun);
 const ground=new THREE.Mesh(new THREE.PlaneGeometry(100,240),new THREE.MeshStandardMaterial({color:0x43854a}));ground.rotation.x=-Math.PI/2;ground.position.z=-75;scene.add(ground);
 roadGroup=new THREE.Group();scene.add(roadGroup);
 const road=new THREE.Mesh(new THREE.PlaneGeometry(13,220),new THREE.MeshStandardMaterial({color:0x30363b,roughness:.95}));road.rotation.x=-Math.PI/2;road.position.set(0,.02,-85);roadGroup.add(road);
 const lineMat=new THREE.MeshStandardMaterial({color:0xffffff});
 for(let z=12;z>-190;z-=9){const dash=new THREE.Mesh(new THREE.BoxGeometry(.18,.035,4),lineMat);dash.position.set(0,.06,z);roadGroup.add(dash)}
 for(const x of [-6.25,6.25]){const edge=new THREE.Mesh(new THREE.BoxGeometry(.16,.04,220),lineMat);edge.position.set(x,.07,-85);roadGroup.add(edge)}
 // finish line near far end of the road
 const finish=new THREE.Group();for(let i=0;i<12;i++){const tile=new THREE.Mesh(new THREE.BoxGeometry(1.08,.06,.75),new THREE.MeshStandardMaterial({color:i%2?0xffffff:0x111111}));tile.position.set(-5.95+(i%6)*2.38,.09,-174+Math.floor(i/6)*.75);finish.add(tile)}scene.add(finish);
 for(let z=8;z>-180;z-=15)for(const x of [-12,12]){const trunk=new THREE.Mesh(new THREE.CylinderGeometry(.18,.25,2,7),new THREE.MeshStandardMaterial({color:0x705035}));trunk.position.set(x,1,z);scene.add(trunk);const crown=new THREE.Mesh(new THREE.ConeGeometry(1.8,4,7),new THREE.MeshStandardMaterial({color:0x176b42}));crown.position.set(x,3.5,z);scene.add(crown)}
 const playerList=Object.entries(roomData?.players||{});
 const mineData=roomData?.players?.[playerId]||{};
 const otherData=playerList.find(([id])=>id!==playerId)?.[1]||{};
 const mineBuild=mineData.build||getBuild(),otherBuild=otherData.build||{color:"blue"};
 const mine=makeCar(carColors[mineBuild.color]||carColors[selectedCar],mineBuild);mine.position.set(-2.1,0,5);scene.add(mine);
 const opp=makeCar(carColors[otherBuild.color]||0x238eea,otherBuild);opp.position.set(2.1,0,5);scene.add(opp);carMeshes=[mine,opp];
 const resize=()=>{if(!renderer)return;camera.aspect=root.clientWidth/root.clientHeight;camera.updateProjectionMatrix();renderer.setSize(root.clientWidth,root.clientHeight)};
 window.addEventListener("resize",resize);
}
function startRaceView(){
 show("race");progress=0;opponentProgress=0;raceStarted=false;finishShown=false;
 initScene();
 const cd=$("countdown");let n=3;cd.textContent="3";
 const timer=setInterval(()=>{n--;cd.textContent=n>0?String(n):n===0?"انطلق!":"";
 if(n<0){clearInterval(timer);raceStarted=true;$("raceMessage").textContent="اضغط باستمرار للتسارع!"}},1000);
 if(unsub)unsub();
 unsub=onValue(ref(db,`rooms/${roomId}/players`),snap=>{
   const ps=snap.val()||{};const other=Object.entries(ps).find(([id])=>id!==playerId);
   if(other){opponentProgress=other[1].progress||0;$("opHud").textContent=`${other[1].name}: ${Math.floor(opponentProgress)}%`;if(other[1].finished&&!finishShown)finishRace(other[1].name,false)}
 });
 animate();
}
function animate(){
 animationId=requestAnimationFrame(animate);
 const myBuild=roomData?.players?.[playerId]?.build||getBuild();
 const engineBoost=1+(Math.max(1,Math.min(3,Number(myBuild.engine||1)))-1)*0.16;
 if(raceStarted&&!finishShown&&gas)progress=Math.min(100,progress+.42*engineBoost);
 if(carMeshes.length){carMeshes[0].position.z=5-progress*1.55;carMeshes[1].position.z=5-opponentProgress*1.55;}
 $("myHud").textContent=`أنت: ${Math.floor(progress)}%`;
 const now=Date.now();if(now-lastSend>140&&db&&roomId){lastSend=now;update(ref(db,`rooms/${roomId}/players/${playerId}`),{progress,finished:progress>=100}).catch(()=>{})}
 if(progress>=100&&!finishShown){update(ref(db,`rooms/${roomId}/players/${playerId}`),{finished:true,progress:100});finishRace(playerName,true)}
 if(renderer)renderer.render(scene,camera);
}
function finishRace(name,me){if(finishShown)return;finishShown=true;gas=false;if(animationId)cancelAnimationFrame(animationId);$("winnerText").textContent=me?"🏆 فزت بالسباق!":`🏆 الفائز: ${name}`;$("resultDetails").textContent=me?"وصلت إلى خط النهاية أولاً!":"انتهى السباق. جرّب مرة ثانية!";show("result")}
const gasBtn=$("gasButton");gasBtn.addEventListener("pointerdown",e=>{e.preventDefault();gas=true});["pointerup","pointercancel","pointerleave"].forEach(ev=>gasBtn.addEventListener(ev,()=>gas=false));
